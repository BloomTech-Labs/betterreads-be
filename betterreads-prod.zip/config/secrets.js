module.exports = {
	jwtsecret: process.env.JWT_SECRET || "secrets secrets secrets"
};
